DelphiMEX

Version 0.95 - October 2000

(c) 2000 Alexandre Kampouris

For general information, and the most current version, 
please refer to http://Radio-BIP.qc.ca/DelphiMex/DelphiMEX.html 

Files included :
    Readme.txt       :  This file.
	DelphiMEX.pas    :  The MEX interfacing unit
	abs2.pas         :  A test program calculating a simple mathematical function
	abs2.dll         :  Compiled version of the previous.
	Speed.m          :  Matlab test driver for the function, with comparisons
	GNU-LGPL.txt     :  Conditions for use

Instructions for compiling and sample programs may be found 
in abs2.pas and delphimex.pas.

The compiled DLL must be somewhere in the Matlab path in order to work. 

The usage of this software is subject to the conditions set out in the GNU LGPL, the
terms of which are included in the file GNU-LGPL.TXT.

Have fun! I'd appreciate hearing from you at DelphiMEX@Radio-BIP.qc.ca .

Alexandre
