clear all;

% 
% DelphiMex
% (c) 2000 Alexandre Kampouris
% mailto:DelphiMex@Radio-BIP.qc.ca
% 
% Elementary test driver for abs2 DLL.
%
% This Matlab script call the DelphiMEX abs2 function, and compares
% its speed with that of several other methods to compute the
% square of the norm, some of them smart, and some of them not
% so smart.
% 

% Define the size of the test matrices.
% The shape of the matrix doesn't, and shouldn't, affect timing results,
% but it doesn't hurt to check.
switch 1,
case 1, mm = 240; nn = mm; 
case 2, mm = 40; nn = 6*240;
case 3, mm = 6*240; nn = 40;
end;


% Define the number of iterations.
ii = 100;

% Create test data sets, and preallocate storage for the results
z=exp(2*pi*j*rand(mm,nn)).*randn(mm,nn);
p=real(z);
r = abs(z);

% Everything fits in real storage.
% paging should not occur. Other applications
% turned off. Tests are then looped 
% to improve timer resolution.
whos p z r

% The following statement has the effect of preloading abs2 in memory before
% the start of the test.
abs2(1);

tic; for i=1:ii;p=abs2(z);end;
disp(sprintf('p=abs2(z)                               %5.3fs',toc));

tic; for i=1:ii;p=real(z).^2+imag(z).^2;end;
disp(sprintf('p=real(z).^2+imag(z).^2                 %5.3fs',toc));

tic; for i=1:ii;p=abs(z).^2;end;
disp(sprintf('p=abs(z).^2                             %5.3fs',toc));

tic; for i=1:ii;p=real(z).*real(z)+imag(z).*imag(z);end;
disp(sprintf('p=real(z).*real(z)+imag(z).*imag(z)     %5.3fs',toc));

tic; for i=1:ii;p=z.*conj(z);end;
disp(sprintf('p=z.*conj(z)                            %5.3fs',toc));

disp('The following methods and computations are less relevant');
disp('Press ENTER, or ^C if you wish to stop');
pause;

tic; for i=1:ii;p=abs(z).*abs(z);end;
disp(sprintf('p=abs(z).*abs(z)                        %5.3fs',toc));

tic; for i=1:ii;p=exp(2*real(log(z)));end;
disp(sprintf('p=exp(2*real(log(z)))                   %5.3fs',toc));

tic; for i=1:ii;p=abs(z);end;
disp(sprintf('p=abs(z)                                %5.3fs',toc));

tic; for i=1:ii;p=r.^2;end;
disp(sprintf('p=r.^2                                  %5.3fs',toc));

tic; for i=1:ii;p=z.^2;end;
disp(sprintf('p=z.^2                                  %5.3fs',toc));

tic; for i=1:ii;p=sqrt(r);end;
disp(sprintf('p=sqrt(r)                               %5.3fs',toc));

tic; for i=1:ii;p=real(z);end;
disp(sprintf('p=real(z)                               %5.3fs',toc));

tic; for i=1:ii;p=real(z)*pi;end;
disp(sprintf('p=real(z)*pi                            %5.3fs',toc));

tic; for i=1:ii;p=real(z)*123.456;end;
disp(sprintf('p=real(z)*123.456                       %5.3fs',toc));

tic; for i=1:ii;p=p*876.543;end;
disp(sprintf('p=p*876.543                             %5.3fs',toc));

tic; for i=1:ii;p=r;end;
disp(sprintf('p=r                                     %5.3fs',toc));

tic; for i=1:ii;p=r+r;end;
disp(sprintf('p=r+r                                   %5.3fs',toc));

tic; for i=1:ii;p=r+r+r;end;
disp(sprintf('p=r+r+r                                 %5.3fs',toc));
