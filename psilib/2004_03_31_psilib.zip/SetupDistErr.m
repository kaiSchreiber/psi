function n=SetupDistErr(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p)

% function nd=SetupDistErr(n_fc,n_x,x_min,x_max,pse,n_pse,sd_pse,nsd_pse,
%        slope,n_slope,sd_slope,nsd_slope,p_err,n_p_err,sd_p_err,nsd_p_err)
%
% Sets up a full Dist. 
%
% n_fc     number of alternatives in the task
% n_x      number of possible stimulus intensities
% x_min    lower limit of these intensities
% x_max    upper limit of these intensities
% pse      center of the prior gaussian distribution for pse
% n_pse    number of values of pse that should be considered
% sd_pse   standard deviation of that distribution
% nsd_pse  extent of pse in standard deviations around e that should be considered
% 
% slope and p_err work the same way as pse.

% This is part of the PSI Matlab library for adaptive Bayesian estimation 
% of the slope, threshold and miss-rate of the psychometric function.
%
% Kai Schreiber, 3/11/2004

if ~libisloaded('psi'),
    loadlibrary('psi.dll','psi.h');
end

n=calllib('psi','SetupDistErr',a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p);